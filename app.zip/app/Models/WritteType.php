<?php

namespace App\Models;

use Eloquent;

class WritteType extends Eloquent
{
    //
}
